package boukevanzon.Anchiano;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnchianoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnchianoApplication.class, args);
	}

}
