package boukevanzon.Anchiano.enums;

public enum TaskStatus {
    BACKLOG, TODO, IN_PROGRESS, DONE, ARCHIVED
}
