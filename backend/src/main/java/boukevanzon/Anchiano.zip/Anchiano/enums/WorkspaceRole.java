package boukevanzon.Anchiano.enums;

public enum WorkspaceRole {
    OWNER, ADMIN, MEMBER, GUEST
}
