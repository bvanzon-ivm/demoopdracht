package boukevanzon.Anchiano.controller;

import boukevanzon.Anchiano.dto.TaskDto;
import boukevanzon.Anchiano.model.Task;
import boukevanzon.Anchiano.service.task.TaskService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.Optional;


import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/workspaces/{workspaceId}/tasks")
public class TaskController {

    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @GetMapping
    public ResponseEntity<List<TaskDto>> getTasks(
            Authentication auth,
            @PathVariable Long workspaceId
    ) {
        List<Task> tasks = taskService.getTasks(auth, workspaceId);
        List<TaskDto> dtos = tasks.stream().map(TaskDto::fromEntity).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @PostMapping
    public ResponseEntity<TaskDto> createTask(
            Authentication auth,
            @PathVariable Long workspaceId,
            @RequestBody TaskDto dto
    ) {
        Task created = taskService.createTask(auth, workspaceId, dto);
        return ResponseEntity.ok(TaskDto.fromEntity(created));
    }

    @PutMapping("/{taskId}")
    public ResponseEntity<TaskDto> updateTask(
            Authentication auth,
            @PathVariable Long workspaceId,
            @PathVariable Long taskId,
            @RequestBody TaskDto dto
    ) {
        Task updated = taskService.updateTask(auth, workspaceId, taskId, dto);
        return ResponseEntity.ok(TaskDto.fromEntity(updated));
    }

    @DeleteMapping("/{taskId}")
    public ResponseEntity<Void> deleteTask(
            Authentication auth,
            @PathVariable Long workspaceId,
            @PathVariable Long taskId
    ) {
        taskService.deleteTask(auth, workspaceId, taskId);
        return ResponseEntity.noContent().build();
    }
}
