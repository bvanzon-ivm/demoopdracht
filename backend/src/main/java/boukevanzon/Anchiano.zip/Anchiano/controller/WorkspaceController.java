package boukevanzon.Anchiano.controller;

import boukevanzon.Anchiano.dto.*;
import boukevanzon.Anchiano.service.workspace.WorkspaceService;

import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/workspaces")
public class WorkspaceController {

    private final WorkspaceService workspaceService;

    public WorkspaceController(WorkspaceService workspaceService) {
        this.workspaceService = workspaceService;
    }

    @GetMapping
    public List<WorkspaceItemDto> getMine(Authentication auth) {
        return workspaceService.getMyWorkspaces(auth);
    }

    @PostMapping
    public ResponseEntity<WorkspaceDetailDto> create(Authentication auth,
                                                     @RequestBody WorkspaceDto req) {
        WorkspaceDetailDto dto = workspaceService.createWorkspace(auth, req);
        return ResponseEntity.status(HttpStatus.CREATED).body(dto);
    }

    @GetMapping("/{id}")
    public WorkspaceDetailDto getById(@PathVariable Long id, Authentication auth) {
        return workspaceService.getWorkspaceDetail(auth, id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id, Authentication auth) {
        workspaceService.deleteWorkspace(auth, id);
        return ResponseEntity.noContent().build();
    }
}
