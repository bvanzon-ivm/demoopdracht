package boukevanzon.Anchiano.controller;

import boukevanzon.Anchiano.model.Label;
import boukevanzon.Anchiano.service.LabelService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/workspaces/{workspaceId}/labels")
public class LabelController {

    private final LabelService labelService;

    public LabelController(LabelService labelService) {
        this.labelService = labelService;
    }

    @GetMapping
    public ResponseEntity<List<Label>> getLabels(
            Authentication auth,
            @PathVariable Long workspaceId
    ) {
        return ResponseEntity.ok(labelService.getLabels(auth, workspaceId));
    }

    @PostMapping
    public ResponseEntity<Label> createLabel(
            Authentication auth,
            @PathVariable Long workspaceId,
            @RequestBody Label label
    ) {
        return ResponseEntity.ok(labelService.createLabel(auth, workspaceId, label));
    }

    @PutMapping("/{labelId}")
    public ResponseEntity<Label> updateLabel(
            Authentication auth,
            @PathVariable Long workspaceId,
            @PathVariable Long labelId,
            @RequestBody Label updated
    ) {
        return ResponseEntity.ok(labelService.updateLabel(auth, workspaceId, labelId, updated));
    }

    @DeleteMapping("/{labelId}")
    public ResponseEntity<Void> deleteLabel(
            Authentication auth,
            @PathVariable Long workspaceId,
            @PathVariable Long labelId
    ) {
        labelService.deleteLabel(auth, workspaceId, labelId);
        return ResponseEntity.noContent().build();
    }
}
