package boukevanzon.Anchiano.controller;

import boukevanzon.Anchiano.dto.AuditDto;
import boukevanzon.Anchiano.service.AuditService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/workspaces/{workspaceId}/audit")
public class AuditController {

    private final AuditService auditService;

    public AuditController(AuditService auditService) {
        this.auditService = auditService;
    }

    @GetMapping
    public ResponseEntity<List<AuditDto>> getAudits(@PathVariable Long workspaceId,
                                                          Authentication auth) {
        return ResponseEntity.ok(auditService.getAudits(auth, workspaceId));
    }
}
