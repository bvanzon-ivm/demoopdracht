package boukevanzon.Anchiano.controller;

import boukevanzon.Anchiano.service.MembershipService;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/workspaces/{workspaceId}/members")
public class MembershipController {

    private final MembershipService membershipService;

    public MembershipController(MembershipService membershipService) {
        this.membershipService = membershipService;
    }

    @PostMapping
    public ResponseEntity<Void> addMember(@PathVariable Long workspaceId,
                                          @RequestBody Map<String, Object> body,
                                          Authentication auth) {
        membershipService.addMemberByEmail(auth, workspaceId, body);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @DeleteMapping("/{userId}")
    public ResponseEntity<Void> removeMember(@PathVariable Long workspaceId,
                                             @PathVariable Long userId,
                                             Authentication auth) {
        membershipService.removeMember(auth, workspaceId, userId);
        return ResponseEntity.noContent().build();
    }
}
