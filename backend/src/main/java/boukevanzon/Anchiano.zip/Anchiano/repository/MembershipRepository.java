package boukevanzon.Anchiano.repository;

import boukevanzon.Anchiano.model.Membership;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MembershipRepository extends JpaRepository<Membership, Long> {
    boolean existsByWorkspace_IdAndUser_Id(Long workspaceId, Long userId);
    long countByWorkspace_Id(Long workspaceId);
    void deleteByWorkspace_IdAndUser_Id(Long workspaceId, Long userId);
    List<Membership> findByWorkspace_Id(Long workspaceId);
    List<Membership> findByUser_Id(Long userId);
}

