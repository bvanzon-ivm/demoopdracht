package boukevanzon.Anchiano.repository;

import boukevanzon.Anchiano.model.Label;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface LabelRepository extends JpaRepository<Label, Long> {

    // Alle labels binnen een workspace ophalen
    List<Label> findByWorkspace_Id(Long workspaceId);

    // Labels binnen een workspace ophalen op naam (handig voor TaskCrudService)
    List<Label> findByWorkspace_IdAndNameIn(Long workspaceId, List<String> names);

    // Specifiek label in workspace op naam zoeken
    Optional<Label> findByWorkspace_IdAndName(Long workspaceId, String name);

    // Alleen actieve labels (bijvoorbeeld voor dropdowns in de frontend)
    List<Label> findByWorkspace_IdAndActiveTrue(Long workspaceId);
}
