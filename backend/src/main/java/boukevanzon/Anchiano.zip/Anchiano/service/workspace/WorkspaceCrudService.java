package boukevanzon.Anchiano.service.workspace;

import boukevanzon.Anchiano.model.User;
import boukevanzon.Anchiano.model.Workspace;
import boukevanzon.Anchiano.repository.WorkspaceRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class WorkspaceCrudService {

    private final WorkspaceRepository workspaceRepository;

    public WorkspaceCrudService(WorkspaceRepository workspaceRepository) {
        this.workspaceRepository = workspaceRepository;
    }

    public Workspace create(String name, String description, User owner) {
        Workspace ws = new Workspace();
        ws.setName(name);
        ws.setDescription(description);
        ws.setOwner(owner);
        ws.setCreatedAt(LocalDateTime.now());
        ws.setUpdatedAt(LocalDateTime.now());
        return workspaceRepository.save(ws);
    }

    public void delete(Workspace workspace) {
        workspaceRepository.delete(workspace);
    }
}
