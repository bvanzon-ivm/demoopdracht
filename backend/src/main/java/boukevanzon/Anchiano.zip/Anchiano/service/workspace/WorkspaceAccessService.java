package boukevanzon.Anchiano.service.workspace;

import boukevanzon.Anchiano.model.User;
import boukevanzon.Anchiano.model.Workspace;
import boukevanzon.Anchiano.repository.MembershipRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class WorkspaceAccessService {

    private final MembershipRepository membershipRepository;

    public WorkspaceAccessService(MembershipRepository membershipRepository) {
        this.membershipRepository = membershipRepository;
    }

    public boolean isOwner(User user, Workspace workspace) {
        return workspace.getOwner() != null &&
               workspace.getOwner().getId().equals(user.getId());
    }

    public boolean isMember(Long workspaceId, Long userId) {
        return membershipRepository.existsByWorkspace_IdAndUser_Id(workspaceId, userId);
    }

    public void requireOwner(User user, Workspace workspace) {
        if (!isOwner(user, workspace)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Only owner allowed");
        }
    }

    public void requireAccess(User user, Workspace workspace) {
        if (!(isOwner(user, workspace) || isMember(workspace.getId(), user.getId()))) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "No access to this workspace");
        }
    }
}
