package boukevanzon.Anchiano.service.task;

import boukevanzon.Anchiano.model.Task;
import boukevanzon.Anchiano.model.User;
import boukevanzon.Anchiano.model.Workspace;
import boukevanzon.Anchiano.repository.MembershipRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class TaskAccessService {

    private final MembershipRepository membershipRepository;

    public TaskAccessService(MembershipRepository membershipRepository) {
        this.membershipRepository = membershipRepository;
    }

    public void checkWorkspaceAccess(User user, Workspace ws) {
        boolean isOwner = ws.getOwner() != null && ws.getOwner().getId().equals(user.getId());
        boolean isMember = membershipRepository.existsByWorkspace_IdAndUser_Id(ws.getId(), user.getId());
        if (!(isOwner || isMember)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Not allowed in this workspace");
        }
    }

    public void checkTaskAccess(User user, Task task) {
        checkWorkspaceAccess(user, task.getWorkspace());
    }
}
