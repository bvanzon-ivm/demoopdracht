package boukevanzon.Anchiano.service.task;

import boukevanzon.Anchiano.dto.TaskDto;
import boukevanzon.Anchiano.enums.TaskStatus;
import boukevanzon.Anchiano.model.Label;
import boukevanzon.Anchiano.model.Task;
import boukevanzon.Anchiano.model.User;
import boukevanzon.Anchiano.model.Workspace;
import boukevanzon.Anchiano.repository.LabelRepository;
import boukevanzon.Anchiano.repository.TaskRepository;
import boukevanzon.Anchiano.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class TaskCrudService {

    private final TaskRepository taskRepository;
    private final UserRepository userRepository;
    private final LabelRepository labelRepository;

    public TaskCrudService(TaskRepository taskRepository,
                           UserRepository userRepository,
                           LabelRepository labelRepository) {
        this.taskRepository = taskRepository;
        this.userRepository = userRepository;
        this.labelRepository = labelRepository;
    }

    public Task create(TaskDto dto, Workspace workspace, User creator) {
        Task task = new Task();
        task.setTitle(dto.getTitle());
        task.setDescription(dto.getDescription());
        task.setPriority(dto.getPriority());
        task.setStatus(dto.getStatus() != null ? dto.getStatus() : TaskStatus.BACKLOG);
        task.setDueDate(dto.getDueDate());
        task.setWorkspace(workspace);
        task.setCreatedBy(creator);
        task.setCreatedAt(LocalDateTime.now());
        task.setUpdatedAt(LocalDateTime.now());

        // Labels koppelen
        if (dto.getLabels() != null && !dto.getLabels().isEmpty()) {
            List<Label> labels = labelRepository.findByWorkspace_IdAndNameIn(
                    workspace.getId(), dto.getLabels()
            );
            task.setLabels(labels);
        }

        // Assignees koppelen
        if (dto.getAssigneeIds() != null && !dto.getAssigneeIds().isEmpty()) {
            List<User> assignees = userRepository.findAllById(dto.getAssigneeIds());
            task.setAssignees(assignees);
        }

        return taskRepository.save(task);
    }

    public List<Task> listByWorkspace(Long workspaceId) {
        return taskRepository.findByWorkspace_IdAndDeletedAtIsNull(workspaceId);
    }

    public Task update(Task task, TaskDto dto) {
        task.setTitle(dto.getTitle());
        task.setDescription(dto.getDescription());
        task.setPriority(dto.getPriority());
        task.setStatus(dto.getStatus() != null ? dto.getStatus() : TaskStatus.BACKLOG);
        task.setDueDate(dto.getDueDate());
        task.setUpdatedAt(LocalDateTime.now());

        // Labels opnieuw koppelen
        if (dto.getLabels() != null) {
            List<Label> labels = labelRepository.findByWorkspace_IdAndNameIn(
                    task.getWorkspace().getId(), dto.getLabels()
            );
            task.setLabels(labels);
        }

        // Assignees opnieuw koppelen
        if (dto.getAssigneeIds() != null) {
            List<User> assignees = userRepository.findAllById(dto.getAssigneeIds());
            task.setAssignees(assignees);
        }

        return taskRepository.save(task);
    }

    public void delete(Task task) {
        task.setDeletedAt(LocalDateTime.now());
        taskRepository.save(task);
    }
}
