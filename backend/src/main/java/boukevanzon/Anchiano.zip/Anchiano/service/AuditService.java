package boukevanzon.Anchiano.service;

import boukevanzon.Anchiano.dto.AuditDto;
import boukevanzon.Anchiano.model.*;
import boukevanzon.Anchiano.repository.AuditRepository;
import boukevanzon.Anchiano.repository.UserRepository;
import boukevanzon.Anchiano.repository.WorkspaceRepository;
import org.springframework.security.core.Authentication;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AuditService {

    private final AuditRepository auditRepository;
    private final WorkspaceRepository workspaceRepository;
    private final UserRepository userRepository;

    public AuditService(AuditRepository auditRepository,
                        WorkspaceRepository workspaceRepository,
                        UserRepository userRepository) {
        this.auditRepository = auditRepository;
        this.workspaceRepository = workspaceRepository;
        this.userRepository = userRepository;
    }

    private User requireMe(Authentication auth) {
        return userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED));
    }

    public List<AuditDto> getAudits(Authentication auth, Long workspaceId) {
        User me = requireMe(auth);

        Workspace ws = workspaceRepository.findById(workspaceId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        // Alleen owner mag audit logs bekijken
        if (!ws.getOwner().getId().equals(me.getId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Only owner can view audits");
        }

        return getLogsForWorkspace(workspaceId);
    }

    public List<AuditDto> getLogsForWorkspace(Long workspaceId) {
        return auditRepository.findByWorkspace_Id(workspaceId).stream()
                .map(log -> new AuditDto(
                        log.getId(),
                        log.getWorkspace().getId(),
                        log.getUser() != null ? log.getUser().getId() : null,
                        log.getUserName(),
                        log.getUserEmail(),
                        log.getAction(),
                        log.getTimestamp(),
                        log.getOldValue(),
                        log.getNewValue()
                ))
                .collect(Collectors.toList());
    }
}
