package boukevanzon.Anchiano.service.workspace;

import boukevanzon.Anchiano.dto.UserDto;
import boukevanzon.Anchiano.dto.WorkspaceDetailDto;
import boukevanzon.Anchiano.dto.WorkspaceItemDto;
import boukevanzon.Anchiano.model.User;
import boukevanzon.Anchiano.model.Workspace;
import boukevanzon.Anchiano.repository.MembershipRepository;
import boukevanzon.Anchiano.repository.WorkspaceRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WorkspaceQueryService {

    private final WorkspaceRepository workspaceRepository;
    private final MembershipRepository membershipRepository;

    public WorkspaceQueryService(WorkspaceRepository workspaceRepository,
                                 MembershipRepository membershipRepository) {
        this.workspaceRepository = workspaceRepository;
        this.membershipRepository = membershipRepository;
    }

    public List<WorkspaceItemDto> getVisibleWorkspaces(User me) {
        List<Workspace> visible = workspaceRepository.findAllVisibleToUser(me.getId());
        return visible.stream()
                .map(ws -> new WorkspaceItemDto(
                        ws.getId(),
                        ws.getName(),
                        ws.getDescription(),
                        new UserDto(ws.getOwner().getId(), ws.getOwner().getName(), ws.getOwner().getEmail()),
                        me.getId().equals(ws.getOwner().getId()),
                        (int) membershipRepository.countByWorkspace_Id(ws.getId())
                ))
                .toList();
    }

    public WorkspaceDetailDto toDetailDto(Workspace ws, User me, List<UserDto> members) {
        return new WorkspaceDetailDto(
                ws.getId(),
                ws.getName(),
                ws.getDescription(),
                new UserDto(ws.getOwner().getId(), ws.getOwner().getName(), ws.getOwner().getEmail()),
                me.getId().equals(ws.getOwner().getId()),
                members
        );
    }
}
