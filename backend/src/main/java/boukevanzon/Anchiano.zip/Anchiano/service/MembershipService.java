package boukevanzon.Anchiano.service;

import boukevanzon.Anchiano.model.*;
import boukevanzon.Anchiano.repository.*;
import boukevanzon.Anchiano.service.workspace.WorkspaceService;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;
import java.util.Optional;

@Service
public class MembershipService {

    private final WorkspaceRepository workspaceRepository;
    private final MembershipRepository membershipRepository;
    private final UserRepository userRepository;
    private final WorkspaceService workspaceService;

    public MembershipService(WorkspaceRepository workspaceRepository,
                                      MembershipRepository membershipRepository,
                                      UserRepository userRepository,
                                      WorkspaceService workspaceService) {
        this.workspaceRepository = workspaceRepository;
        this.membershipRepository = membershipRepository;
        this.userRepository = userRepository;
        this.workspaceService = workspaceService;
    }

    public void addMemberByEmail(Authentication auth, Long workspaceId, Map<String, Object> body) {
        User me = workspaceService.requireMe(auth);
        Workspace ws = workspaceService.requireWorkspace(workspaceId);

        if (!me.getId().equals(ws.getOwner().getId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Only owner can add members");
        }

        String email = Optional.ofNullable(body.get("email"))
                .map(Object::toString)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "email required"));

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));

        if (!membershipRepository.existsByWorkspace_IdAndUser_Id(workspaceId, user.getId())) {
            Membership membership = new Membership();
            membership.setWorkspace(ws);
            membership.setUser(user);
            membershipRepository.save(membership);
        }
    }

    public void removeMember(Authentication auth, Long workspaceId, Long userId) {
        User me = workspaceService.requireMe(auth);
        Workspace ws = workspaceService.requireWorkspace(workspaceId);

        if (!me.getId().equals(ws.getOwner().getId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Only owner can remove members");
        }

        membershipRepository.deleteByWorkspace_IdAndUser_Id(workspaceId, userId);
    }
}
