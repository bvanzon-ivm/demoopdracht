package boukevanzon.Anchiano.service.task;

import boukevanzon.Anchiano.dto.TaskDto;
import boukevanzon.Anchiano.model.Task;
import boukevanzon.Anchiano.model.User;
import boukevanzon.Anchiano.model.Workspace;
import boukevanzon.Anchiano.repository.TaskRepository;
import boukevanzon.Anchiano.service.workspace.WorkspaceService;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class TaskService {

    private final TaskCrudService crud;
    private final TaskAccessService access;
    private final WorkspaceService workspaceService;
    private final TaskRepository taskRepository;

    public TaskService(TaskCrudService crud,
                       TaskAccessService access,
                       WorkspaceService workspaceService,
                       TaskRepository taskRepository) {
        this.crud = crud;
        this.access = access;
        this.workspaceService = workspaceService;
        this.taskRepository = taskRepository;
    }

    // Controller roept nu getTasks() aan
    public List<Task> getTasks(Authentication auth, Long workspaceId) {
        User me = workspaceService.requireMe(auth);
        Workspace ws = workspaceService.requireWorkspace(workspaceId);
        access.checkWorkspaceAccess(me, ws);
        return crud.listByWorkspace(workspaceId);
    }

    public Task createTask(Authentication auth, Long workspaceId, TaskDto dto) {
        User me = workspaceService.requireMe(auth);
        Workspace ws = workspaceService.requireWorkspace(workspaceId);
        access.checkWorkspaceAccess(me, ws);
        return crud.create(dto, ws, me);
    }

    public Task updateTask(Authentication auth, Long workspaceId, Long taskId, TaskDto dto) {
        User me = workspaceService.requireMe(auth);
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new IllegalArgumentException("Task not found"));
        access.checkTaskAccess(me, task);
        return crud.update(task, dto);
    }

    public void deleteTask(Authentication auth, Long workspaceId, Long taskId) {
        User me = workspaceService.requireMe(auth);
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new IllegalArgumentException("Task not found"));
        access.checkTaskAccess(me, task);
        crud.delete(task);
    }
}
