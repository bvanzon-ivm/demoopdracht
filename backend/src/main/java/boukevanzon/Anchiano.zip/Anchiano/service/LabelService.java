package boukevanzon.Anchiano.service;

import boukevanzon.Anchiano.dto.UserDto;
import boukevanzon.Anchiano.model.Label;
import boukevanzon.Anchiano.model.User;
import boukevanzon.Anchiano.model.Workspace;
import boukevanzon.Anchiano.repository.LabelRepository;
import boukevanzon.Anchiano.repository.WorkspaceRepository;
import boukevanzon.Anchiano.service.workspace.WorkspaceService;
import boukevanzon.Anchiano.service.workspace.WorkspaceAccessService;


import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class LabelService {

    private final LabelRepository labelRepository;
    private final WorkspaceRepository workspaceRepository;
    private final WorkspaceService workspaceService;

    public LabelService(LabelRepository labelRepository,
                        WorkspaceRepository workspaceRepository,
                        WorkspaceService workspaceService) {
        this.labelRepository = labelRepository;
        this.workspaceRepository = workspaceRepository;
        this.workspaceService = workspaceService;
    }

    private Workspace requireWorkspaceForMember(Authentication auth, Long workspaceId) {
        User me = workspaceService.requireMe(auth);
        Workspace ws = workspaceService.requireWorkspace(workspaceId);

        // Alleen leden of eigenaar van workspace hebben toegang
        if (!(workspaceService.isOwner(me, ws) || workspaceService.isMember(ws.getId(), me.getId()))) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "No access to this workspace");
        }
        return ws;
    }

    public List<Label> getLabels(Authentication auth, Long workspaceId) {
        requireWorkspaceForMember(auth, workspaceId);
        return labelRepository.findByWorkspace_IdAndActiveTrue(workspaceId);
    }

    public Label createLabel(Authentication auth, Long workspaceId, Label label) {
        Workspace ws = requireWorkspaceForMember(auth, workspaceId);
        label.setWorkspace(ws);
        label.setCreatedAt(LocalDateTime.now());
        label.setUpdatedAt(LocalDateTime.now());
        return labelRepository.save(label);
    }

    public Label updateLabel(Authentication auth, Long workspaceId, Long labelId, Label updated) {
        Workspace ws = requireWorkspaceForMember(auth, workspaceId);

        Label label = labelRepository.findById(labelId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Label not found"));

        if (!label.getWorkspace().getId().equals(ws.getId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Label does not belong to workspace");
        }

        label.setName(updated.getName());
        label.setColor(updated.getColor());
        label.setDescription(updated.getDescription());
        label.setActive(updated.isActive());
        label.setUpdatedAt(LocalDateTime.now());

        return labelRepository.save(label);
    }

    public void deleteLabel(Authentication auth, Long workspaceId, Long labelId) {
        Workspace ws = requireWorkspaceForMember(auth, workspaceId);

        Label label = labelRepository.findById(labelId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Label not found"));

        if (!label.getWorkspace().getId().equals(ws.getId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Label does not belong to workspace");
        }

        // Hard delete of soft delete? Hier soft d7elete: active = false
        label.setActive(false);
        label.setUpdatedAt(LocalDateTime.now());
        labelRepository.save(label);
    }
}
