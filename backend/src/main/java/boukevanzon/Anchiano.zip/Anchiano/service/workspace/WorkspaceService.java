package boukevanzon.Anchiano.service.workspace;

import boukevanzon.Anchiano.dto.UserDto;
import boukevanzon.Anchiano.dto.WorkspaceDetailDto;
import boukevanzon.Anchiano.dto.WorkspaceDto;
import boukevanzon.Anchiano.dto.WorkspaceItemDto;
import boukevanzon.Anchiano.model.User;
import boukevanzon.Anchiano.model.Workspace;
import boukevanzon.Anchiano.repository.UserRepository;
import boukevanzon.Anchiano.repository.WorkspaceRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class WorkspaceService {

    private final WorkspaceCrudService crudService;
    private final WorkspaceQueryService queryService;
    private final WorkspaceAccessService accessService;
    private final WorkspaceRepository workspaceRepository;
    private final UserRepository userRepository;

    public WorkspaceService(WorkspaceCrudService crudService,
                            WorkspaceQueryService queryService,
                            WorkspaceAccessService accessService,
                            WorkspaceRepository workspaceRepository,
                            UserRepository userRepository) {
        this.crudService = crudService;
        this.queryService = queryService;
        this.accessService = accessService;
        this.workspaceRepository = workspaceRepository;
        this.userRepository = userRepository;
    }

    public User requireMe(Authentication auth) {
        return userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED));
    }

    public Workspace requireWorkspace(Long id) {
        return workspaceRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    public List<WorkspaceItemDto> getMyWorkspaces(Authentication auth) {
        User me = requireMe(auth);
        return queryService.getVisibleWorkspaces(me);
    }

    public WorkspaceDetailDto getWorkspaceDetail(Authentication auth, Long id, List<UserDto> members) {
        User me = requireMe(auth);
        Workspace ws = requireWorkspace(id);
        accessService.requireAccess(me, ws);
        return queryService.toDetailDto(ws, me, members);
    }

    public Workspace createWorkspace(Authentication auth, WorkspaceDto dto) {
        User me = requireMe(auth);
        return crudService.create(dto.name(), dto.description(), me);
    }

    public void deleteWorkspace(Authentication auth, Long id) {
        User me = requireMe(auth);
        Workspace ws = requireWorkspace(id);
        accessService.requireOwner(me, ws);
        crudService.delete(ws);
    }
}
