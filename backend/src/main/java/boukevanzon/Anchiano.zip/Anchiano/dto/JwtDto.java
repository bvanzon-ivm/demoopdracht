package boukevanzon.Anchiano.dto;

import boukevanzon.Anchiano.model.User;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JwtDto {
    private String token;
    private String type = "Bearer";
    private User user;

    public JwtDto(String token, User user) {
        this.token = token;
        this.user = user;
    }

}
