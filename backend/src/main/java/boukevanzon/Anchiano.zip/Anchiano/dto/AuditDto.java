package boukevanzon.Anchiano.dto;

import java.time.LocalDateTime;

public record AuditDto(
        Long id,
        Long workspaceId,
        Long user,
        String userName,
        String userEmail,
        String action,
        LocalDateTime timestamp,
        String oldValue,
        String newValue
) {}