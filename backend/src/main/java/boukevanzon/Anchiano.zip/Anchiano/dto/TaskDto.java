package boukevanzon.Anchiano.dto;

import boukevanzon.Anchiano.enums.TaskPriority;
import boukevanzon.Anchiano.enums.TaskStatus;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import boukevanzon.Anchiano.model.Task;
import boukevanzon.Anchiano.model.Label;
import boukevanzon.Anchiano.model.User;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Data

public class TaskDto {
    @NotBlank private String title;
    private String description;
    private TaskPriority priority = TaskPriority.MEDIUM;
    private TaskStatus status = TaskStatus.TODO;
    private LocalDateTime dueDate;
    private Long workspaceId;
    private Long createdBy;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    private List<String> labels;
    private List<Long> assigneeIds;


        // 🔹 Entity -> DTO
    public static TaskDto fromEntity(Task task) {
        TaskDto dto = new TaskDto();
        dto.setTitle(task.getTitle());
        dto.setDescription(task.getDescription());
        dto.setPriority(task.getPriority());
        dto.setStatus(task.getStatus());
        dto.setDueDate(task.getDueDate());
        dto.setWorkspaceId(task.getWorkspace().getId());
        dto.setCreatedBy(task.getCreatedBy() != null ? task.getCreatedBy().getId() : null);
        dto.setCreatedAt(task.getCreatedAt());
        dto.setUpdatedAt(task.getUpdatedAt());

        // labels als namen doorgeven
        if (task.getLabels() != null) {
            dto.setLabels(task.getLabels().stream()
                    .map(Label::getName)
                    .collect(Collectors.toList()));
        }

        // assignees als ids doorgeven
        if (task.getAssignees() != null) {
            dto.setAssigneeIds(task.getAssignees().stream()
                    .map(User::getId)
                    .collect(Collectors.toList()));
        }

        return dto;
    }

    // 🔹 DTO -> Entity (bij create/update)
    public Task toEntity() {
        Task task = new Task();
        task.setTitle(this.title);
        task.setDescription(this.description);
        task.setPriority(this.priority);
        task.setStatus(this.status);
        task.setDueDate(this.dueDate);
        return task;
    }
}
