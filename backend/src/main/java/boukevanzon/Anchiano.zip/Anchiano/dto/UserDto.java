// dto/UserDto.java
package boukevanzon.Anchiano.dto;

public record UserDto(Long id, String name, String email) {}
