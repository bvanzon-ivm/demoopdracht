// CreateWorkspaceRequest.java
package boukevanzon.Anchiano.dto;

public record WorkspaceDto(String name, String description) {}
