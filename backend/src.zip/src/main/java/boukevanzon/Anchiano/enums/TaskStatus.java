package boukevanzon.Anchiano.enums;

public enum TaskStatus {
    TODO, IN_PROGRESS, DONE, ARCHIVED
}
