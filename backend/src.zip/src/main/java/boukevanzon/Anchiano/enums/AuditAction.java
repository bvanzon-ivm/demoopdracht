package boukevanzon.Anchiano.enums;

public enum AuditAction {
    CREATE, UPDATE, DELETE, RESTORE
}