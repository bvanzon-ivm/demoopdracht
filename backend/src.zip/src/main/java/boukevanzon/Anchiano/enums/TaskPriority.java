package boukevanzon.Anchiano.enums;

public enum TaskPriority {
    LOW, MEDIUM, HIGH, URGENT
}

