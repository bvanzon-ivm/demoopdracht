// CreateWorkspaceRequest.java
package boukevanzon.Anchiano.dto;

public record CreateWorkspaceRequest(String name, String description) {}
